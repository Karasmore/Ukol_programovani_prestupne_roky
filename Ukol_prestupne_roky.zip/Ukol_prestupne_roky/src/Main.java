import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            System.out.println("Vyberte jednu možnost:");
            System.out.println("1. Zjištění přestupného roku podle zadaného roku od uživatele");
            System.out.println("2. Zjištění přestupného roku podle současného data");
            System.out.println("3. Vlastní formát data a času podle systémového času");
            System.out.println("4. Zbývající čas do určitého data");
            System.out.println("5. Ukončení programu");
            System.out.print("Vyber: ");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Zadej rok: ");
                    int userInputYear = scanner.nextInt();
                    boolean isLeapYear = isLeapYear(userInputYear);
                    System.out.println("Rok " + userInputYear + " je " + (isLeapYear ? "přestupný" : "neprůstupný") + " rok.");
                    break;
                case 2:
                    int currentYear = Calendar.getInstance().get(Calendar.YEAR);
                    System.out.println("Aktuální rok je " + currentYear);
                    if (isLeapYear(currentYear)) {
                        System.out.println("Je to přestupný rok.");
                    } else {
                        System.out.println("Následující přestupný rok bude " + findNextLeapYear(currentYear));
                    }
                    break;
                case 3:
                    SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                    long currentTimeMillis = System.currentTimeMillis();
                    Date currentDate = new Date(currentTimeMillis);
                    String formattedDate = dateFormat.format(currentDate);
                    System.out.println("Součastný systémový čas je: " + formattedDate);
                    break;
                case 4:
                    System.out.print("Zadej den: ");
                    int day = scanner.nextInt();
                    System.out.print("Zadej  měsíc: ");
                    int month = scanner.nextInt();
                    System.out.print("Zadej rok: ");
                    int year = scanner.nextInt();

                    Calendar targetDate = Calendar.getInstance();
                    targetDate.set(year, month - 1, day);

                    Calendar date = Calendar.getInstance();
                    long timeDifferenceMillis = targetDate.getTimeInMillis() - date.getTimeInMillis();

                    int days = (int) (timeDifferenceMillis / (1000 * 60 * 60 * 24));
                    int hours = (int) ((timeDifferenceMillis / (1000 * 60 * 60)) % 24);
                    int minutes = (int) ((timeDifferenceMillis / (1000 * 60)) % 60);
                    int seconds = (int) (timeDifferenceMillis / 1000 % 60);

                    System.out.println("Zbývá " + days + " dní, " + hours + " hodin, " + minutes + " minut, " + seconds + " sekund do zadaného data.");
                    break;
                case 5:
                    running = false;
                    break;
                default:
                    System.out.println("Neplatná možnost. Zadej znovu.");
            }
        }
    }
    public static boolean isLeapYear(int year) {
        if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) {
            return true;
        } else {
            return false;
        }
    }
    public static int findNextLeapYear(int currentYear) {
        while (true) {
            currentYear++;
            if (isLeapYear(currentYear)) {
                return currentYear;
            }
        }
    }
}
